package com.keyin.rest.domain;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import java.util.List;

@RepositoryRestResource(collectionResourceRel = "member", path = "member")
public interface MemberRepository extends JpaRepository<Member, Long> {

    //find member by name
    public List<Member> findByLastName(@Param("lastName") String lastName);
    public List<Member> findByFirstName(@Param("firstName") String firstName);
    public List<Member> findByEmailAddress(@Param("emailAddress") String emailAddress);
    public List<Member> findByAddress(@Param("address") String address);

    // search by multiple fields
    public List<Member> findByLastNameAndFirstName(@Param("lastName") String lastName, @Param("firstName") String firstName);


    // find members tournaments
    
   


    
}